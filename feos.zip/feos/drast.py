crauset.hove example
crist.besolve tr.matrix
drops.trope

63 72 61 75 73 65 74 2E 68 6F 76 65 20 65 78 61 6D 70 6C 65 A 63 72 69 73 74 2E 62 65 73 6F 6C 76 65 20 74 72 2E 6D 61 74 72 69 78 A 64 72 6F 70 73 2E 74 72 6F 70 65